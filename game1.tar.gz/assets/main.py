# Module Import
import pgzrun
import pygame
import random
import asyncio

# Print console run successful
print("Run Success!")

# Variables
game_state = "Menu"         # The Game's State
Card_Deck = []              # Whole Deck
Player_Count = 0            # Amount of Players
Player_Hands = {}           # Player's Cards
Center_Pile = []            # Cards at Center Pile
Current_Turn = 1            # Tracker for Player's Turn
Winner_Name = ""            # Winner's Name

# AI Pacing & Behavior Controls
AI_Slap_Timer = 0           # Counts frames after a card is played
AI_Slap_Delay = random.randint(20, 50)  # How many frames the AI waits to slap (randomized!)
AI_Has_Reacted = False      # Prevents the AI from repeatedly slapping the same double

AI_Turn_Timer = 0           # NEW: Counts frames to delay the AI's card placement
AI_Turn_Delay = 60          # NEW: How many frames the AI waits to place a card (60 frames = 1 full second)

# Pygame Rect's
Start_Btn_Rect = pygame.Rect(0, 0, 250, 80)
Start_Btn_Rect.center = (800, 600)
N2P_Btn_Rect = pygame.Rect(500, 450, 250, 80)
N3P_Btn_Rect = pygame.Rect(850, 450, 250, 80)
Center_Pile_Rect = pygame.Rect(0, 0, 300, 450)
Center_Pile_Rect.center = (800, 400)
Restart_Btn_Rect = pygame.Rect(0, 0, 250, 80)
Restart_Btn_Rect.center = (800, 550)


WIDTH = 1600
HEIGHT = 800

# Functions
def Setup_and_Deal_Cards(num_players):
    global Player_Hands, Center_Pile, Current_Turn, AI_Slap_Timer, AI_Has_Reacted, AI_Slap_Delay, AI_Turn_Timer
    
    Card_Suits = ["Hearts", "Spades", "Diamonds", "Clubs"]
    Card_Ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
    Card_Deck = [(i2, i1) for i1 in Card_Suits for i2 in Card_Ranks]
    random.shuffle(Card_Deck)
    
    # Reset table trackers completely
    Center_Pile = [] 
    Current_Turn = 1
    AI_Slap_Timer = 0
    AI_Turn_Timer = 0 # Reset turn timer
    AI_Has_Reacted = False
    AI_Slap_Delay = random.randint(20, 150)
    
    # Initialize dynamic list slots for each player key
    Player_Hands = {f"Player {i}": [] for i in range(1, num_players + 1)}
    for index, card in enumerate(Card_Deck):
        player_num = (index % num_players) + 1
        Player_Hands[f"Player {player_num}"].append(card)

def draw():
    screen.fill((50, 50, 50))
    
    if game_state == "Menu":
        screen.draw.text("Egyptian Rat Slap", center=(800, 200), fontsize=60)
        screen.draw.filled_rect(Start_Btn_Rect, (128, 0, 0))
        screen.draw.text("Start!", center=(800, 600), fontsize=40)
        
    elif game_state == "Select_Players":
        screen.fill((30, 90, 50))
        screen.draw.text("Select Amount of Players", center=(800, 200), fontsize=60)
        screen.draw.filled_rect(N2P_Btn_Rect, (35, 45, 35))
        screen.draw.text("2 Players", center=N2P_Btn_Rect.center, fontsize=36)
        screen.draw.filled_rect(N3P_Btn_Rect, (35, 45, 35))
        screen.draw.text("3 Players", center=N3P_Btn_Rect.center, fontsize=36)
        
    elif game_state == "Playing":
        screen.fill((150, 76, 29))
        screen.draw.text(f"The Table - {Player_Count} Players - Press Space to Set Card", center=(800, 40), fontsize=40)
        screen.draw.text(f"Current Turn: Player {Current_Turn}", center=(800, 90), fontsize=32, color="white")
        
        # 1. Main Center Card Pile (Top Card)
        screen.draw.filled_rect(Center_Pile_Rect, (255, 255, 255))
        
        if len(Center_Pile) > 0:
            top_card = Center_Pile[-1]
            Rank, Suit = top_card
            Card_Txt_Color = "red" if Suit in ("Hearts", "Diamonds") else "black"
            screen.draw.text(f"{Rank} of", center=(800, 370), fontsize=48, color=Card_Txt_Color)
            screen.draw.text(Suit, center=(800, 430), fontsize=48, color=Card_Txt_Color)
        else:
            screen.draw.text("No Cards Played", center=Center_Pile_Rect.center, fontsize=32, color="grey")
            
        # 2. Side-by-Side History Layout (At the bottom of the screen)
        screen.draw.text("History (Oldest ──► Newest):", (475, 640), fontsize=24, color="white")
        
        # Define 3 historical small box rects positioned horizontally near the bottom
        # Box sizes are 150px wide, 90px tall, sitting at Y=670
        box1_rect = pygame.Rect(475, 670, 150, 90) # 3rd card down (Oldest)
        box2_rect = pygame.Rect(650, 670, 150, 90) # 2nd card down
        box3_rect = pygame.Rect(825, 670, 150, 90) # Top card duplicate (Newest)
        
        # CARD 1: 3rd card down (Center_Pile[-3])
        if len(Center_Pile) >= 3:
            screen.draw.filled_rect(box1_rect, (255, 255, 255))
            r, s = Center_Pile[-3]
            c = "red" if s in ("Hearts", "Diamonds") else "black"
            screen.draw.text(f"{r} of {s}", center=box1_rect.center, fontsize=20, color=c)
            
        # CARD 2: 2nd card down (Center_Pile[-2])
        if len(Center_Pile) >= 2:
            screen.draw.filled_rect(box2_rect, (255, 255, 255))
            r, s = Center_Pile[-2]
            c = "red" if s in ("Hearts", "Diamonds") else "black"
            screen.draw.text(f"{r} of {s}", center=box2_rect.center, fontsize=20, color=c)
            
        # CARD 3: Current Top Card Duplicate (Center_Pile[-1])
        if len(Center_Pile) >= 1:
            screen.draw.filled_rect(box3_rect, (255, 255, 255))
            r, s = Center_Pile[-1]
            c = "red" if s in ("Hearts", "Diamonds") else "black"
            screen.draw.text(f"{r} of {s}", center=box3_rect.center, fontsize=20, color=c)

        # Draw sidebar indicators highlighting current player hands sizing
        y_offset = 200
        for Player_Name, Hands in Player_Hands.items():
            screen.draw.text(f"{Player_Name}: {len(Hands)} cards", (50, y_offset), fontsize=32)
            y_offset += 60
    elif game_state == "GameOver":
        screen.fill((20, 20, 30)) # Dark dramatic background
        
        # Victory Text
        screen.draw.text("👑 MATCH COMPLETED 👑", center=(800, 200), fontsize=60, color="yellow")
        screen.draw.text(f"{Winner_Name} Wins the Game!", center=(800, 320), fontsize=48, color="white")
        screen.draw.text("All 52 cards collected!", center=(800, 400), fontsize=28, color="grey")
        
        # Draw Restart Button
        screen.draw.filled_rect(Restart_Btn_Rect, (0, 100, 0)) # Green button
        screen.draw.text("Play Again", center=Restart_Btn_Rect.center, fontsize=36, color="white")





def update():
    global Current_Turn, Center_Pile, Player_Hands, AI_Slap_Timer, AI_Has_Reacted, AI_Slap_Delay, AI_Turn_Timer, game_state, Winner_Name

    if game_state == "Playing":
        Current_Player_Key = f"Player {Current_Turn}"

        # 1. AUTOMATIC AI TURNS (If turn belongs to Player 2 or Player 3)
        if Current_Player_Key != "Player 1":
            # Count frames up to simulate the AI "thinking" before playing its card
            AI_Turn_Timer += 1
            
            if AI_Turn_Timer >= AI_Turn_Delay:
                if len(Player_Hands[Current_Player_Key]) > 0:
                    Card_Played = Player_Hands[Current_Player_Key].pop(0)
                    Center_Pile.append(Card_Played)
                    
                    # Fresh card placed: reset slap timers and generate a fresh random slap delay
                    AI_Slap_Timer = 0
                    AI_Has_Reacted = False
                    AI_Slap_Delay = random.randint(20, 150)
                    
                    # Reset the turn timer for the next AI round
                    AI_Turn_Timer = 0
                    
                    # Cycle turns forward
                    Current_Turn += 1
                    if Current_Turn > Player_Count:
                        Current_Turn = 1
                else:
                    # If this AI is out of cards, reset timer and skip turn automatically
                    AI_Turn_Timer = 0
                    Current_Turn += 1
                    if Current_Turn > Player_Count:
                        Current_Turn = 1

        # 2. AUTOMATIC AI REACTION SLAPPING
        if len(Center_Pile) >= 2 and not AI_Has_Reacted:
            is_slap_present = False
            
            # AI scans for a Double
            if Center_Pile[-1][0] == Center_Pile[-2][0]:
                is_slap_present = True
                
            # AI scans for a Sandwich (only if there are 3+ cards on the table)
            elif len(Center_Pile) >= 3 and Center_Pile[-1][0] == Center_Pile[-3][0]:
                is_slap_present = True

            if is_slap_present:
                AI_Slap_Timer += 1
                
                # If human player didn't slap fast enough, AI strikes!
                if AI_Slap_Timer >= AI_Slap_Delay:
                    # Give the cards to the AI (Player 2)
                    Player_Hands["Player 2"].extend(Center_Pile)
                    Center_Pile.clear()
                    AI_Has_Reacted = True
                    print("The AI opponent slapped the pile first!")
        # 3. GAME OVER WINNER CHECK
        # Look through all active hands to see if someone reached 52 cards
        for Player_Name, Hands in Player_Hands.items():
            if len(Hands) == 52:
                Winner_Name = Player_Name
                game_state = "GameOver"


def on_mouse_down(pos):
    global game_state, Player_Count
    
    if game_state == "Menu":
        if Start_Btn_Rect.collidepoint(pos):
            game_state = "Select_Players"
            
    elif game_state == "Select_Players":
        if N2P_Btn_Rect.collidepoint(pos):
            Player_Count = 2
            Setup_and_Deal_Cards(Player_Count)
            game_state = "Playing"
        elif N3P_Btn_Rect.collidepoint(pos):
            Player_Count = 3
            Setup_and_Deal_Cards(Player_Count)
            game_state = "Playing"
    elif game_state == "GameOver":
        if Restart_Btn_Rect.collidepoint(pos):
            game_state = "Menu" # Bounce back to the main menu to start a fresh game!


def on_key_down(key):
    global Current_Turn, Center_Pile, Player_Hands, AI_Has_Reacted, AI_Slap_Timer, AI_Slap_Delay, AI_Turn_Timer
    
    if game_state == "Playing":
        Current_Player_Key = f"Player {Current_Turn}"
        
        # Place A Card -- Action 1 (Only allowed if it is actually Player 1's turn)
        if key == keys.SPACE and Current_Player_Key == "Player 1":
            if len(Player_Hands["Player 1"]) > 0:
                Card_Played = Player_Hands["Player 1"].pop(0)
                Center_Pile.append(Card_Played)
                
                # Fresh card placed: reset AI reaction timers and generate a fresh random slap delay
                AI_Slap_Timer = 0
                AI_Has_Reacted = False
                AI_Slap_Delay = random.randint(20, 150)
                
                # Reset AI turn timer so it waits its full delay *after* you place a card
                AI_Turn_Timer = 0
                
                # Cycle turns forward
                Current_Turn += 1
                if Current_Turn > Player_Count:
                    Current_Turn = 1

        # Slap The Deck -- Action 2 (Human player hits ENTER)
        elif key == keys.RETURN:
            # Initialize success flag
            is_valid_slap = False
            
            # Condition A: Check for a Double (requires at least 2 cards)
            if len(Center_Pile) >= 2:
                if Center_Pile[-1][0] == Center_Pile[-2][0]:
                    is_valid_slap = True
                    print("Nice! You successfully slapped a Double!")
            
            # Condition B: Check for a Sandwich (requires at least 3 cards)
            if len(Center_Pile) >= 3 and not is_valid_slap:
                if Center_Pile[-1][0] == Center_Pile[-3][0]:
                    is_valid_slap = True
                    print("Nice! You successfully slapped a Sandwich!")

            # Execute the result based on the check
            if is_valid_slap:
                Player_Hands["Player 1"].extend(Center_Pile)
                Center_Pile.clear()
                AI_Has_Reacted = True
            else:
                # PENALTY: Invalid slap burns a card to the very bottom
                if len(Player_Hands["Player 1"]) > 0:
                    burned_card = Player_Hands["Player 1"].pop(0)
                    Center_Pile.insert(0, burned_card)
                    print("Whops! Invalid slap. You burned a card to the bottom of the stack.")

async def main():
    pgzrun.go()
    while True:
        await asyncio.sleep(0)

asyncio.run(main())
